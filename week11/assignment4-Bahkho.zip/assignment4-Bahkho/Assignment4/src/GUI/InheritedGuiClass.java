package GUI;

import Classes.Cat;
import Classes.Dog;
import Classes.Lion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InheritedGuiClass extends JFrame {
    //I will simulate the same approach in 2ndGuiApp
    //Constructor:
    public InheritedGuiClass(){

        //I will create 3 objects of Cat,Lion,Dog:
        Lion myLion = new Lion("Lion",600,"Jungle",true,60);
        //Cat
        Cat myCat = new Cat("Cat", 20.0,"House", false,6);
        //Dog
        Dog myDog = new Dog("Dog", 70, "Street OR House", false,"Shiba");

        setTitle("ABC Zoo App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setBounds(10,10,500,600);

        Font fontName = new Font("Courier", Font.BOLD, 20);



        //I will create the parent JPanel:
        //JPanel is the object that contains the control objects like (JButton, JLabel , ... , etc)
        JPanel parentPanel = new JPanel();
        //I will assign the parent panel to the content pane attribute of the JFrame:
        setContentPane(parentPanel); //this.contentPane = parentPanel;
        parentPanel.setLayout(new CardLayout(10,10));

        //Now, I will create the children of the parentPanel:
        //The first child: ------------------------------------------------------------//
        JPanel firstPanel = new JPanel();
        firstPanel.setLayout(null);
        parentPanel.add(firstPanel);
        firstPanel.setBackground(Color.GREEN);

        //I will add the control objects in firstPanel:
        JLabel firstLabel = new JLabel("Select a species:");
        firstLabel.setBounds(50,100,200,30);
        firstPanel.add(firstLabel);

        //You need to declare a 3 radioButtons:

        JRadioButton catRadioButton = new JRadioButton("Cat");
        JRadioButton dogRadioButton = new JRadioButton("Dog");
        JRadioButton lionRadioButton = new JRadioButton("Lion");

        catRadioButton.setBounds(50,140,100,30);
        dogRadioButton.setBounds(50,180,100,30);
        lionRadioButton.setBounds(50,220,100,30);

        ButtonGroup animalGroup = new ButtonGroup();
        animalGroup.add(catRadioButton);
        animalGroup.add(dogRadioButton);
        animalGroup.add(lionRadioButton);

        firstPanel.add(catRadioButton);
        firstPanel.add(dogRadioButton);
        firstPanel.add(lionRadioButton);

        //You will add actionListeners for each of them. See the firstBtn actionListener below:


        // Name Label
        JLabel nameLabel = new JLabel();
        nameLabel.setBounds(100,260,200,30);
        nameLabel.setText("Done by Abdulwahab: W0484585");
        firstPanel.add(nameLabel);

        // Sample Button
//        JButton firstBtn = new JButton("Go To Panel Two");
//        firstBtn.setBounds(50,300,200,30);
//        firstPanel.add(firstBtn);

        // The second child: ------------------------------------------------------//
        JPanel secondPanel = new JPanel();
        secondPanel.setLayout(null);
        parentPanel.add(secondPanel);
        secondPanel.setBackground(Color.pink);

        //I will add the required control objects:
        JLabel secondLabel = new JLabel("Species");
        secondLabel.setBounds(50,30,100,30);
        secondPanel.add(secondLabel);

        JTextField speciesTxt = new JTextField();
        speciesTxt.setBounds(150,30,200,30);
        speciesTxt.setFont(fontName);
        secondPanel.add(speciesTxt);

        JLabel amountOfFoodLabel = new JLabel("Amount of Food");
        amountOfFoodLabel.setBounds(50,70,100,30);
        secondPanel.add(amountOfFoodLabel);

        JTextField amountOfFoodTxt = new JTextField();
        amountOfFoodTxt.setBounds(150,70,200,30);
        amountOfFoodTxt.setFont(fontName);
        secondPanel.add(amountOfFoodTxt);

        JLabel imageLabel = new JLabel();
        imageLabel.setBounds(50,120,500,180);
        secondPanel.add(imageLabel);
        //imageLabel.setIcon(new ImageIcon(getClass().getResource("/Images/cat.jpg")));

        JTextArea textArea = new JTextArea();
        textArea.setBounds(50, 320, 300, 160);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(fontName);
        secondPanel.add(textArea);

        // Go back
        JButton secondBtn = new JButton("Go Back");
        secondBtn.setBounds(50,500,200,30);
        secondPanel.add(secondBtn);


        //ActionListeners: ----------------------------------------------------------//
//        firstBtn.addActionListener(new ActionListener(){
//            public void actionPerformed(ActionEvent e){
//                firstPanel.setVisible(false);
//                secondPanel.setVisible(true);
//                speciesTxt.setText(myLion.getSpecies());
//                //textAreaReport.setText(myLion.toString());
//
//                imageLabel.setIcon(new ImageIcon(getClass().getResource("/Classes/Images/lion.jpg")));
//                //I will do the math related to the amount of food:
//                double amountOfFood = 0.15 * myLion.getMaxWeight();
//                speciesTxt.setText(String.format("%.2flb",amountOfFood));
//
//
//            }
//        });

        secondBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                firstPanel.setVisible(true);
                secondPanel.setVisible(false);
            }
        });

        catRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPanel.setVisible(false);
                secondPanel.setVisible(true);
                speciesTxt.setText(String.format("%s", myCat.getSpecies()));

                double amountOfFood = 0.15 * myCat.getMaxWeight();
                amountOfFoodTxt.setText(String.format("%.2flb",amountOfFood));
                imageLabel.setIcon(new ImageIcon(getClass().getResource("/images/cat.jpg")));
                textArea.setText(myCat.toString());
            }
        });

        dogRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPanel.setVisible(false);
                secondPanel.setVisible(true);
                speciesTxt.setText(String.format("%s", myDog.getSpecies()));

                double amountOfFood = 0.15 * myDog.getMaxWeight();
                amountOfFoodTxt.setText(String.format("%.2flb",amountOfFood));
                imageLabel.setIcon(new ImageIcon(getClass().getResource("/images/dog.jpg")));
                textArea.setText(myDog.toString());
            }
        });

        lionRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstPanel.setVisible(false);
                secondPanel.setVisible(true);
                speciesTxt.setText(String.format("%s", myLion.getSpecies()));

                double amountOfFood = 0.15 * myLion.getMaxWeight();
                amountOfFoodTxt.setText(String.format("%.2flb",amountOfFood));
                imageLabel.setIcon(new ImageIcon(getClass().getResource("/images/lion.jpg")));
                textArea.setText(myLion.toString());
            }
        });


    }
}
