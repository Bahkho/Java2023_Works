//import classes.Circle;
//import classes.Square;
//import classes.Triangle;

import classes.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Tech Check 1");

//        Circle myCircle = new Circle("Circle","Red",10);
//        Square mySquare = new Square("Square","Blue",12);
//        Triangle myTriangle = new Triangle("Triangle","White",10,5);
//
//        System.out.println("The circle's area is: " +myCircle.getArea());
//        System.out.println("The square's area is: " +mySquare.getArea());
//        System.out.println("The triangle's area is: " +myTriangle.getArea());


        new GUIClass1();
    }
}